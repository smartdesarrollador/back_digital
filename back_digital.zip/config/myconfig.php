<?php

return [
    'url_upload_banner' => env('URL_UPLOAD_BANNER', 'assets/imagen/banner'),
    'url_upload_carousel' => env('URL_UPLOAD_CAROUSEL', 'assets/imagen/carousel'),
    'url_upload_mision' => env('URL_UPLOAD_MISION', 'assets/imagen/mision'),
    'url_upload_producto' => env('URL_UPLOAD_PRODUCTO', 'assets/imagen/producto'),
];